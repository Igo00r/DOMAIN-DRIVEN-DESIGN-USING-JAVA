package org.example;

import org.example.AnnotationProcessor;
import org.example.Carta;

import javax.xml.catalog.CatalogFeatures;
import javax.xml.transform.Source;
import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        var carta = new Carta();
        AnnotationProcessor.processDataFields(carta);
        System.out.println(carta);
//        var scan = new Scanner(System.in);
//        var carta = new Carta();
//        System.out.println("digite o nome da carta:");
//        carta.setNome(scan.nextLine());
//        System.out.println("Digite o texto da carta:");
//        carta.setTexto(scan.nextLine());
//        System.out.println(carta);
    }
}